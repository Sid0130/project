package com.itwill.project.controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import com.itwill.project.model.Reception;
import com.itwill.project.model.ReceptionData;
import com.itwill.project.model.ReceptionDetails;
import com.itwill.project.model.ReceptionDetails.ReceptionDetailsBuilder;

import static com.itwill.project.model.Animal.Entity.*;
import static com.itwill.project.model.Owner.Entity.*;
import static com.itwill.project.model.Doctor.Entity.*;
import static com.itwill.project.model.Reception.Entity.*;
import static com.itwill.project.oracle.OracleJdbc.*;

import oracle.jdbc.OracleDriver;

public enum ReceptionDao {
	INSTANCE;

	ReceptionDao() {
		try {
			DriverManager.registerDriver(new OracleDriver()); // 오라클에 드라이버 등록

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	private void closeResources(Connection conn, Statement stmt, ResultSet rs) {
		try {
			if (rs != null)	rs.close();
			if (stmt != null) stmt.close();
			if (conn != null) conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private void closeResources(Connection conn, Statement stmt) {
		closeResources(conn, stmt, null);
	}
	
	public ReceptionData getAppointmentFormResultSet(ResultSet rs) throws SQLException {
		//TODO: 예약시간
		int receptionId = rs.getInt(COL_RECEPTION_ID);
		Timestamp receptionAppointmentTime = rs.getTimestamp(COL_RECEPTION_APPOINTMENTTIME); //예약시간
		String receptionStatus = rs.getString(COL_RECEPTION_STATUS); //예약
		Timestamp receptionCreatedTime = rs.getTimestamp(COL_RECEPTION_CREATED_TIME);
		Timestamp receptionModifiedTime = rs.getTimestamp(COL_RECEPTION_MODIFIED_TIME);
		
		String animalName = rs.getString(COL_ANIMAL_NAME);
		String animalGender = rs.getString(COL_ANIMAL_GENDER);
		String animalType = rs.getString(COL_ANIMAL_TYPE);
		Integer animalAge = rs.getInt(COL_ANIMAL_AGE);
		Double animalWeight = rs.getDouble(COL_ANIMAL_WEIGHT);
		
		String ownerName = rs.getString(COL_OWNER_NAME);
		String doctorName = rs.getString(COL_DOCTOR_NAME);
		
			return ReceptionData.builder()
					.receptionId(receptionId)
					.receptionAppointmentTime(receptionAppointmentTime)
					.receptionStatus(receptionStatus)
					.receptionCreatedTime(receptionCreatedTime)
					.receptionModifiedTime(receptionModifiedTime)
					.animalName(animalName)
					.animalGender(animalGender)
					.animalType(animalType)
					.animalAge(animalAge)
					.animalWeight(animalWeight)
					.ownerName(ownerName)
					.doctorName(doctorName)
					.build();
	}
	
	
	
	public ReceptionData getReceptionDataFormResultSet(ResultSet rs) throws SQLException {
	
	int receptionId = rs.getInt(COL_RECEPTION_ID);
	Timestamp receptionAppointmentTime = rs.getTimestamp(COL_RECEPTION_APPOINTMENTTIME); //예약시간
	String receptionStatus = rs.getString(COL_RECEPTION_STATUS); //예약
	Timestamp receptionCreatedTime = rs.getTimestamp(COL_RECEPTION_CREATED_TIME);
	Timestamp receptionModifiedTime = rs.getTimestamp(COL_RECEPTION_MODIFIED_TIME);
	
	String animalName = rs.getString(COL_ANIMAL_NAME);
	String animalType = rs.getString(COL_ANIMAL_TYPE);
	
	String ownerName = rs.getString(COL_OWNER_NAME);
	String doctorName = rs.getString(COL_DOCTOR_NAME);
	
		return ReceptionData.builder()
				.receptionId(receptionId)
				.receptionAppointmentTime(receptionAppointmentTime)
				.receptionStatus(receptionStatus)
				.receptionCreatedTime(receptionCreatedTime)
				.receptionModifiedTime(receptionModifiedTime)
				.animalName(animalName)
				.animalType(animalType)
				.ownerName(ownerName)
				.doctorName(doctorName)
				.build();
	}
	
	private static final String SQL_JOIN_ALL = String.format(
			"select r.%s, r.%s, r.%s, r.%s, r.%s, a.%s, a.%s, o.%s, d.%s "
			+ "from %s r "
			+ "join animal a on r.animals_id = a.animal_id\r\n"
			+ "join owner o on r.owners_id = o.owner_id\r\n"
			+ "join doctor d on r.doctors_id = d.doctor_id;", 
			COL_RECEPTION_ID,COL_RECEPTION_APPOINTMENTTIME,COL_RECEPTION_STATUS,
			COL_RECEPTION_CREATED_TIME, COL_DOCTOR_MODIFIED_TIME,
			COL_ANIMAL_NAME, COL_ANIMAL_TYPE, COL_OWNER_NAME, COL_DOCTOR_NAME,
			
			TBL_RECEPTION,
			
			TBL_ANIMAL, COL_RECEPTION_ANIMAL_ID, COL_ANIMAL_ID,
			TBL_OWNER, COL_RECEPTION_OWNER_ID, COL_OWNER_ID,
			TBL_DOCTOR, COL_RECEPTION_DOCTOR_ID, COL_DOCTOR_ID);
	
	public List<ReceptionData> read(){
		List<ReceptionData> receptiondata = new ArrayList<>();
		
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		
		try {
			conn = DriverManager.getConnection(URL, USER, PASSWORD);
			stmt = conn.prepareCall(SQL_JOIN_ALL);
			rs = stmt.executeQuery();
			
			if(rs.next()) {
				ReceptionData rd = getReceptionDataFormResultSet(rs);
				receptiondata.add(rd);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			closeResources(conn, stmt, rs);
		}
		
		return receptiondata;
	
	}
			
		
			
	
	
	
	
	
	
}
