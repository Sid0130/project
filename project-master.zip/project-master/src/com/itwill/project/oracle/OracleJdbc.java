package com.itwill.project.oracle;

public interface OracleJdbc {
	String URL = "jdbc:oracle:thin:@Localhost:1521:xe";
	String USER = "hc";
	String PASSWORD = "hc";
}
