package com.itwill.project.view;

import java.awt.Component;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import com.itwill.project.controller.DoctorDao;
import com.itwill.project.controller.PetDao;
import com.itwill.project.model.Animal;
import com.itwill.project.model.AnimalOwner;
import com.itwill.project.model.Doctor;
import com.itwill.project.view.PetCreateFrame.CreateNotify;
import java.awt.event.ActionListener;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionEvent;

public class ReceptionFrame extends JFrame {
	
	public interface SelectNotify {
		void notifySelectSuccess();
	}
	
	private static final String[] APPOINTMENT = {
		"예약", "진료중", "대기중"	
	};
	
	private static final String[] SELECT_TYPE = {
			"강아지", "고양이", "기타"
		};
		
	private static final String[] SPECIALTY = {
			"수의내과", "수의외과"
	};

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textOwderField;
	private JTextField textWeightField;
	private JTextField textAgeField;
	private JTextField textGenderField;
	private JTextField textAnimalNameField;
	private JSeparator separator_1;
	private JSeparator separator;
	private JPanel buttonPanel;
	private JButton btnSave;
	private JButton btnCancle;
	private JPanel titlePanel;
	private JLabel titleLabel;
	private JLabel timeLabel;
	private JLabel nameLabel;
	private JLabel typeLabel;
	private JLabel genderLabel;
	private JLabel ageLabel;
	private JLabel weightLabel;
	private JLabel owderLabel;
	private JLabel doctorLabel;
	private JLabel statusLabel;
	private JTextField textDoctorField;
	private JComboBox<String> statusComboBox;
	private JComboBox<String> typeComboBox;
	private DefaultComboBoxModel<String> model;
	
	private Component parentComponent;
	private PetDao petDao;
	private DoctorDao doctorDao;
	private CreateNotify app;
	private JTextField textField;
	private JTextField textDateField;
	private final Integer id;

	
	
	
	
	public static void showReceptionFrame(Component parentComponent, CreateNotify app,Integer id) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ReceptionFrame frame = new ReceptionFrame(parentComponent, app, id);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public ReceptionFrame(Component parentComponent, CreateNotify app, Integer id) {
		petDao = PetDao.INSTANCE;
		this.parentComponent = parentComponent;
		this.app = app;
		this.id = id;
		initialize();
		loadAoData();
	}
	
	/**
	 * Create the frame.
	 */
	public void initialize() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 340, 520);
		setLocationRelativeTo(parentComponent);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		separator_1 = new JSeparator();
		separator_1.setBounds(2, 435, 319, 6);
		contentPane.add(separator_1);
		
		separator = new JSeparator();
		separator.setBounds(2, 41, 319, 6);
		contentPane.add(separator);
		
		buttonPanel = new JPanel();
		buttonPanel.setBounds(0, 440, 324, 34);
		contentPane.add(buttonPanel);
		
		btnCancle = new JButton("취소");
		btnCancle.addActionListener(e -> dispose());
		btnCancle.setFont(new Font("D2Coding", Font.PLAIN, 12));
		buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		
		btnSave = new JButton("접수");
		btnSave.addActionListener(e -> createReception());
		btnSave.setFont(new Font("D2Coding", Font.PLAIN, 12));
		buttonPanel.add(btnSave);
		buttonPanel.add(btnCancle);
		
		titlePanel = new JPanel();
		titlePanel.setBounds(0, 5, 324, 34);
		contentPane.add(titlePanel);
		titlePanel.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		
		titleLabel = new JLabel("접수 정보");
		titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
		titleLabel.setFont(new Font("D2Coding", Font.PLAIN, 20));
		titlePanel.add(titleLabel);
		
		timeLabel = new JLabel("예약일");
		timeLabel.setFont(new Font("D2Coding", Font.PLAIN, 15));
		timeLabel.setBounds(12, 57, 60, 24);
		contentPane.add(timeLabel);
		
		nameLabel = new JLabel("이름");
		nameLabel.setFont(new Font("D2Coding", Font.PLAIN, 15));
		nameLabel.setBounds(67, 127, 60, 24);
		contentPane.add(nameLabel);
		
		typeLabel = new JLabel("분류");
		typeLabel.setFont(new Font("D2Coding", Font.PLAIN, 15));
		typeLabel.setBounds(67, 161, 60, 24);
		contentPane.add(typeLabel);
		
		genderLabel = new JLabel("성별");
		genderLabel.setFont(new Font("D2Coding", Font.PLAIN, 15));
		genderLabel.setBounds(67, 195, 60, 24);
		contentPane.add(genderLabel);
		
		ageLabel = new JLabel("나이");
		ageLabel.setFont(new Font("D2Coding", Font.PLAIN, 15));
		ageLabel.setBounds(67, 229, 60, 24);
		contentPane.add(ageLabel);
		
		weightLabel = new JLabel("체중");
		weightLabel.setFont(new Font("D2Coding", Font.PLAIN, 15));
		weightLabel.setBounds(67, 263, 60, 24);
		contentPane.add(weightLabel);
		
		owderLabel = new JLabel("보호자");
		owderLabel.setFont(new Font("D2Coding", Font.PLAIN, 15));
		owderLabel.setBounds(67, 297, 60, 24);
		contentPane.add(owderLabel);
		
		doctorLabel = new JLabel("주치의");
		doctorLabel.setFont(new Font("D2Coding", Font.PLAIN, 15));
		doctorLabel.setBounds(67, 359, 60, 24);
		contentPane.add(doctorLabel);
		
		statusLabel = new JLabel("상태");
		statusLabel.setFont(new Font("D2Coding", Font.PLAIN, 15));
		statusLabel.setBounds(67, 393, 60, 24);
		contentPane.add(statusLabel);
		
		textDoctorField = new JTextField();
		textDoctorField.setBounds(139, 359, 110, 22);
		contentPane.add(textDoctorField);
		
		statusComboBox = new JComboBox<>();
		model = new DefaultComboBoxModel<>(APPOINTMENT);
		statusComboBox.setModel(model);
		 
		statusComboBox.setBounds(139, 394, 110, 22);
		contentPane.add(statusComboBox);
		
		textOwderField = new JTextField();
		textOwderField.setBounds(139, 297, 110, 22);
		contentPane.add(textOwderField);
		textOwderField.setColumns(10);
		
		textWeightField = new JTextField();
		textWeightField.setColumns(10);
		textWeightField.setBounds(139, 265, 110, 22);
		contentPane.add(textWeightField);
		
		textAgeField = new JTextField();
		textAgeField.setColumns(10);
		textAgeField.setBounds(139, 231, 110, 22);
		contentPane.add(textAgeField);
		
		textGenderField = new JTextField();
		textGenderField.setColumns(10);
		textGenderField.setBounds(139, 197, 110, 22);
		contentPane.add(textGenderField);
		
		textAnimalNameField = new JTextField();
		textAnimalNameField.setColumns(10);
		textAnimalNameField.setBounds(139, 129, 110, 22);
		contentPane.add(textAnimalNameField);
		
		textDateField = new JTextField();
		textDateField.setColumns(10);
		textDateField.setBounds(22, 91, 83, 22);
		contentPane.add(textDateField);
		
		typeComboBox = new JComboBox<>();
		model = new DefaultComboBoxModel<>(SELECT_TYPE);
		typeComboBox.setModel(model);
		typeComboBox.setBounds(139, 163, 110, 22);
		contentPane.add(typeComboBox);
		
		JButton btnNewButton = new JButton("예약 날짜");
		btnNewButton.addActionListener(e -> ReceptionCalendar.showReceptionCalendar(contentPane));
		btnNewButton.setBounds(121, 90, 74, 23);
		contentPane.add(btnNewButton);
		
		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(207, 91, 83, 22);
		contentPane.add(textField);
	}

	private void createReception() {
		String AppointmentTime = textDateField.getText();
		String receptionStatus = (String) statusComboBox.getSelectedItem();
		String animalName = textAnimalNameField.getText();
		String animalType = (String) typeComboBox.getSelectedItem();
		String ownerName = textOwderField.getText();
		String doctorName = textDoctorField.getText();
		
		if(AppointmentTime.equals("")||receptionStatus.equals("")) {
			JOptionPane.showMessageDialog(
					ReceptionFrame.this, 
					"내용은 반드시 입력",
					"경고",
					JOptionPane.WARNING_MESSAGE);
			return;		
		}
	}
	
	private void loadAoData() {
		
		
		AnimalOwner ao = petDao.readAo(id);
		
		textAnimalNameField.setText(ao.getAnimalName());
		typeComboBox.setSelectedItem(ao.getAnimalType());
		textOwderField.setText(ao.getOwnerName());
		textDoctorField.setText(ao.getOwnerName());
		
	}
	
	
	

}
