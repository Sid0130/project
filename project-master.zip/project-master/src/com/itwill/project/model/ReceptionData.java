package com.itwill.project.model;

import java.sql.Timestamp;

public class ReceptionData {

	private Integer receptionId;
	private Integer animalId;
	private Integer doctorId;
	private Integer ownerId;
	private Timestamp receptionAppointmentTime;
	private String receptionStatus;
	private Timestamp receptionCreatedTime;
	private Timestamp receptionModifiedTime;

	private String doctorName;
	private String ownerName;

	private String animalName;
	private String animalType;
	private Integer animalAge;
	private String animalGender;
	private Double animalWeight;

	public ReceptionData() {
	}

	public ReceptionData(Integer receptionId, Integer animalId, Integer doctorId, Integer ownerId,
			Timestamp receptionAppointmentTime, String receptionStatus, Timestamp receptionCreatedTime,
			Timestamp receptionModifiedTime, String doctorName, String ownerName, String animalName, String animalType,
			Integer animalAge, String animalGender, Double animalWeight) {

		this.receptionId = receptionId;
		this.animalId = animalId;
		this.doctorId = doctorId;
		this.ownerId = ownerId;
		this.receptionAppointmentTime = receptionAppointmentTime;
		this.receptionStatus = receptionStatus;
		this.receptionCreatedTime = receptionCreatedTime;
		this.receptionModifiedTime = receptionModifiedTime;
		this.doctorName = doctorName;
		this.ownerName = ownerName;
		this.animalName = animalName;
		this.animalType = animalType;
		this.animalAge = animalAge;
		this.animalGender = animalGender;
		this.animalWeight = animalWeight;

	}

	public Timestamp getReceptionAppointmentTime() {
		return receptionAppointmentTime;
	}

	public void setReceptionAppointmentTime(Timestamp receptionAppointmentTime) {
		this.receptionAppointmentTime = receptionAppointmentTime;
	}

	public String getReceptionStatus() {
		return receptionStatus;
	}

	public void setReceptionStatus(String receptionStatus) {
		this.receptionStatus = receptionStatus;
	}

	public Timestamp getReceptionCreatedTime() {
		return receptionCreatedTime;
	}

	public void setReceptionCreatedTime(Timestamp receptionCreatedTime) {
		this.receptionCreatedTime = receptionCreatedTime;
	}

	public Timestamp getReceptionModifiedTime() {
		return receptionModifiedTime;
	}

	public void setReceptionModifiedTime(Timestamp receptionModifiedTime) {
		this.receptionModifiedTime = receptionModifiedTime;
	}

	public String getDoctorName() {
		return doctorName;
	}

	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}

	public String getOwnerName() {
		return ownerName;
	}

	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}

	public String getAnimalName() {
		return animalName;
	}

	public void setAnimalName(String animalName) {
		this.animalName = animalName;
	}

	public String getAnimalType() {
		return animalType;
	}

	public void setAnimalType(String animalType) {
		this.animalType = animalType;
	}

	public Integer getAnimalAge() {
		return animalAge;
	}

	public void setAnimalAge(Integer animalAge) {
		this.animalAge = animalAge;
	}

	public String getAnimalGender() {
		return animalGender;
	}

	public void setAnimalGender(String animalGender) {
		this.animalGender = animalGender;
	}

	public Double getAnimalWeight() {
		return animalWeight;
	}

	public void setAnimalWeight(Double animalWeight) {
		this.animalWeight = animalWeight;
	}

	public Integer getReceptionId() {
		return receptionId;
	}

	public Integer getAnimalId() {
		return animalId;
	}

	public Integer getDoctorId() {
		return doctorId;
	}

	public Integer getOwnerId() {
		return ownerId;
	}
	
	

	
	@Override
	public String toString() {
		return "ReceptionData [receptionId=" + receptionId + ", animalId=" + animalId + ", doctorId=" + doctorId
				+ ", ownerId=" + ownerId + ", receptionAppointmentTime=" + receptionAppointmentTime
				+ ", receptionStatus=" + receptionStatus + ", receptionCreatedTime=" + receptionCreatedTime
				+ ", receptionModifiedTime=" + receptionModifiedTime + ", doctorName=" + doctorName + ", ownerName="
				+ ownerName + ", animalName=" + animalName + ", animalType=" + animalType + ", animalAge=" + animalAge
				+ ", animalGender=" + animalGender + ", animalWeight=" + animalWeight + "]";
	}

	public static ReceptionDataBuilder builder() {
		return new ReceptionDataBuilder();
		
	}
	
	public static class ReceptionDataBuilder{
		
		private Integer receptionId;
		private Integer animalId;
		private Integer doctorId;
		private Integer ownerId;
		private Timestamp receptionAppointmentTime;
		private String receptionStatus;
		private Timestamp receptionCreatedTime;
		private Timestamp receptionModifiedTime;

		private String doctorName;
		private String ownerName;

		private String animalName;
		private String animalType;
		private Integer animalAge;
		private String animalGender;
		private Double animalWeight;
		
		
		public ReceptionDataBuilder() {	}
		
		public ReceptionDataBuilder(Integer receptionId, Integer animalId, Integer doctorId, Integer ownerId,
				Timestamp receptionAppointmentTime, String receptionStatus, Timestamp receptionCreatedTime,
				Timestamp receptionModifiedTime, String doctorName, String ownerName, String animalName, String animalType,
				Integer animalAge, String animalGender, Double animalWeight) {

			this.receptionId = receptionId;
			this.animalId = animalId;
			this.doctorId = doctorId;
			this.ownerId = ownerId;
			this.receptionAppointmentTime = receptionAppointmentTime;
			this.receptionStatus = receptionStatus;
			this.receptionCreatedTime = receptionCreatedTime;
			this.receptionModifiedTime = receptionModifiedTime;
			this.doctorName = doctorName;
			this.ownerName = ownerName;
			this.animalName = animalName;
			this.animalType = animalType;
			this.animalAge = animalAge;
			this.animalGender = animalGender;
			this.animalWeight = animalWeight;
		}

		public ReceptionDataBuilder receptionId(Integer receptionId) {
			this.receptionId = receptionId;
			return this;
		}
		public ReceptionDataBuilder animalId(Integer animalId) {
			this.animalId = animalId;
			return this;
		}
		public ReceptionDataBuilder doctorId(Integer doctorId) {
			this.doctorId = doctorId;
			return this;
		}
		public ReceptionDataBuilder ownerId(Integer ownerId) {
			this.ownerId = ownerId;
			return this;
		}
		public ReceptionDataBuilder receptionAppointmentTime(Timestamp receptionAppointmentTime) {
			this.receptionAppointmentTime = receptionAppointmentTime;
			return this;
		}
		public ReceptionDataBuilder receptionStatus(String receptionStatus) {
			this.receptionStatus = receptionStatus;
			return this;
		}
		public ReceptionDataBuilder receptionCreatedTime(Timestamp receptionCreatedTime) {
			this.receptionCreatedTime = receptionCreatedTime;
			return this;
		}
		public ReceptionDataBuilder receptionModifiedTime(Timestamp receptionModifiedTime) {
			this.receptionModifiedTime = receptionModifiedTime;
			return this;
		}
		
		public ReceptionDataBuilder doctorName(String doctorName) {
			this.doctorName = doctorName;
			return this;
		}
		
		public ReceptionDataBuilder ownerName(String ownerName) {
			this.ownerName = ownerName;
			return this;
		}
		public ReceptionDataBuilder animalName(String animalName) {
			this.animalName = animalName;
			return this;
		}		public ReceptionDataBuilder animalType(String animalType) {
			this.animalType = animalType;
			return this;
		}
		public ReceptionDataBuilder animalAge(Integer animalAge) {
			this.animalAge = animalAge;
			return this;
		}
		
		public ReceptionDataBuilder animalGender(String animalGender) {
			this.animalGender = animalGender;
			return this;
		}
		public ReceptionDataBuilder animalWeight(Double animalWeight) {
			this.animalWeight = animalWeight;
			return this;
		}

		public ReceptionData build() {
			return new ReceptionData(receptionId, animalId, doctorId, ownerId, receptionAppointmentTime,
					receptionStatus, receptionCreatedTime, receptionModifiedTime, doctorName, ownerName, animalName,
					animalType, animalAge, animalGender, animalWeight);
		}

	}

}
